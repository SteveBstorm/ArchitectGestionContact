﻿using GestionContact.DAL.Interface;
using GestionContact.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionContact.DAL.Services
{
    public class ContactRepository : IContactRepository
    {
        private const string connectionString = @"Data Source=STEVEBSTORM\MSSQLSERVER01;Initial Catalog=ArchitectContact;Integrated Security=True;Connect Timeout=60;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public bool Create(Contact contact)
        {
            string sqlQuery = "INSERT INTO Contact (Firstname, Lastname,Email, Phone) " +
                              "VALUES (@firstname, @lastname, @email, @phone)";

            using(SqlConnection c = new SqlConnection())
            {
                c.ConnectionString = connectionString;

                using(SqlCommand cmd = c.CreateCommand())
                {
                    cmd.CommandText = sqlQuery;
                    cmd.Parameters.AddWithValue("firstname", contact.Firstname);
                    cmd.Parameters.AddWithValue("lastname", contact.Lastname);
                    cmd.Parameters.AddWithValue("email", contact.Email);
                    cmd.Parameters.AddWithValue("phone", contact.Phone);

                    bool result;
                    c.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                    c.Close();
                    return result;
                }
            }
        
        }

        public bool Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Contact> GetAll()
        {
            throw new NotImplementedException();
        }

        public Contact GetById(int id)
        {
            throw new NotImplementedException();
        }

        public bool Update(Contact contact)
        {
            throw new NotImplementedException();
        }
    }
}
